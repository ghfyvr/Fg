"use client"

export default function InitData() {
  // We're removing the demo keys initialization
  // This component now does nothing, but we'll keep it in case we need to add functionality later
  return null
}
